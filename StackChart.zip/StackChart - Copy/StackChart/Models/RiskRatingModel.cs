﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StackChart.Models
{
    public class RiskRatingModel
    {
        public int ReviewInProgressRR1 { get; set; }
        public int ReviewNotStartedRR1 { get; set; }
        public int ReviewPastDueRR1    { get; set; }
        public int ReviewCompletedRR1  { get; set; }
        public int ReviewComplainceRR1 { get; set; }
             
        public int ReviewInProgressRR2 { get; set; }
        public int ReviewNotStartedRR2 { get; set; }
        public int ReviewPastDueRR2    { get; set; }
        public int ReviewCompletedRR2  { get; set; }
        public int ReviewComplainceRR2 { get; set; }
              
        public int ReviewInProgressRR3 { get; set; }
        public int ReviewNotStartedRR3 { get; set; }
        public int ReviewPastDueRR3    { get; set; }
        public int ReviewCompletedRR3  { get; set; }
        public int ReviewComplainceRR3 { get; set; }
              
        public int ReviewInProgressRR4 { get; set; }
        public int ReviewNotStartedRR4 { get; set; }
        public int ReviewPastDueRR4    { get; set; }
        public int ReviewCompletedRR4  { get; set; }
        public int ReviewComplainceRR4 { get; set; }
              
        public int ReviewInProgressRR5  { get; set; }
        public int ReviewNotStartedRR5 { get; set; }
        public int ReviewPastDueRR5    { get; set; }
        public int ReviewCompletedRR5  { get; set; }
        public int ReviewComplainceRR5 { get; set; }
    }
}